(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-editprofile-editprofile-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/editprofile/editprofile.page.html":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/editprofile/editprofile.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesEditprofileEditprofilePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/profile\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Edit Profile</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-label style=\"margin-right: 15px;\">Save</ion-label>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <ion-row>\n    <ion-col size=\"12\">\n      <ion-label>Profile Headline</ion-label>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-input class=\"head_input\"></ion-input>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-label>About Yourself</ion-label>\n    </ion-col>\n    <ion-col size=\"12\">\n      <ion-textarea rows=\"4\" class=\"head_input\"></ion-textarea>\n    </ion-col>\n  </ion-row>\n  <ion-list>\n    <ion-item class=\"gtx\">\n      <ion-label>I am looking for-</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"f\">\n        <ion-select-option value=\"f\">Women</ion-select-option>\n        <ion-select-option value=\"m\">Man</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Country-</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">India </ion-select-option>\n        <ion-select-option value=\"2\">Canada</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>City-</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Kolkata </ion-select-option>\n        <ion-select-option value=\"2\">Torento</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Religion-</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Muslim-Sunni </ion-select-option>\n        <ion-select-option value=\"2\">Muslim-Sufi</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Relationship Status-</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Never Married </ion-select-option>\n        <ion-select-option value=\"2\">Married</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Ethnicity-</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Asian </ion-select-option>\n        <ion-select-option value=\"2\">African</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Country of Origin -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">India </ion-select-option>\n        <ion-select-option value=\"2\">Canada</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Has children -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">No </ion-select-option>\n        <ion-select-option value=\"2\">Yes</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>No of children -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">1 </ion-select-option>\n        <ion-select-option value=\"2\">2</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Wants children -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Yes </ion-select-option>\n        <ion-select-option value=\"2\">No</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Height -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">162 cm </ion-select-option>\n        <ion-select-option value=\"2\">163 cm</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Height -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">70 kg </ion-select-option>\n        <ion-select-option value=\"2\">71 kg</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Body Type -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Muscular</ion-select-option>\n        <ion-select-option value=\"2\">Slim</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Smoking -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">I'll tell you later</ion-select-option>\n        <ion-select-option value=\"2\">No</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Drinks Alcohol -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">I'll tell you later</ion-select-option>\n        <ion-select-option value=\"2\">No</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Education -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Bachelor Degree</ion-select-option>\n        <ion-select-option value=\"2\">No</ion-select-option>\n      </ion-select>\n    </ion-item>\n    <ion-item class=\"gtx\">\n      <ion-label>Occupation -</ion-label>\n      <ion-select placeholder=\"Select One\" value=\"1\">\n        <ion-select-option value=\"1\">Software Devoloper</ion-select-option>\n        <ion-select-option value=\"2\">No</ion-select-option>\n      </ion-select>\n    </ion-item>\n\n  </ion-list>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/editprofile/editprofile-routing.module.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/editprofile/editprofile-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: EditprofilePageRoutingModule */

    /***/
    function srcAppPagesEditprofileEditprofileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditprofilePageRoutingModule", function () {
        return EditprofilePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _editprofile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./editprofile.page */
      "./src/app/pages/editprofile/editprofile.page.ts");

      var routes = [{
        path: '',
        component: _editprofile_page__WEBPACK_IMPORTED_MODULE_3__["EditprofilePage"]
      }];

      var EditprofilePageRoutingModule = function EditprofilePageRoutingModule() {
        _classCallCheck(this, EditprofilePageRoutingModule);
      };

      EditprofilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], EditprofilePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/editprofile/editprofile.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/editprofile/editprofile.module.ts ***!
      \*********************************************************/

    /*! exports provided: EditprofilePageModule */

    /***/
    function srcAppPagesEditprofileEditprofileModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditprofilePageModule", function () {
        return EditprofilePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _editprofile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./editprofile-routing.module */
      "./src/app/pages/editprofile/editprofile-routing.module.ts");
      /* harmony import */


      var _editprofile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./editprofile.page */
      "./src/app/pages/editprofile/editprofile.page.ts");

      var EditprofilePageModule = function EditprofilePageModule() {
        _classCallCheck(this, EditprofilePageModule);
      };

      EditprofilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _editprofile_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditprofilePageRoutingModule"]],
        declarations: [_editprofile_page__WEBPACK_IMPORTED_MODULE_6__["EditprofilePage"]]
      })], EditprofilePageModule);
      /***/
    },

    /***/
    "./src/app/pages/editprofile/editprofile.page.scss":
    /*!*********************************************************!*\
      !*** ./src/app/pages/editprofile/editprofile.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesEditprofileEditprofilePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background: #f4f5f8;\n}\n\n.head_input {\n  background: white;\n  border: 1px solid #ccc;\n  border-radius: 5px;\n  margin: 0;\n}\n\nion-list {\n  background: transparent;\n}\n\nion-list .gtx {\n  --background: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZWRpdHByb2ZpbGUvZWRpdHByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUFDSjs7QUFFQTtFQUNJLGlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUFDSjs7QUFFQTtFQUNJLHVCQUFBO0FBQ0o7O0FBQ0k7RUFDSSx5QkFBQTtBQUNSIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvZWRpdHByb2ZpbGUvZWRpdHByb2ZpbGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZjRmNWY4O1xyXG59XHJcblxyXG4uaGVhZF9pbnB1dCB7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbmlvbi1saXN0IHtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cclxuICAgIC5ndHgge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICB9XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/pages/editprofile/editprofile.page.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/editprofile/editprofile.page.ts ***!
      \*******************************************************/

    /*! exports provided: EditprofilePage */

    /***/
    function srcAppPagesEditprofileEditprofilePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditprofilePage", function () {
        return EditprofilePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var EditprofilePage = /*#__PURE__*/function () {
        function EditprofilePage() {
          _classCallCheck(this, EditprofilePage);
        }

        _createClass(EditprofilePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return EditprofilePage;
      }();

      EditprofilePage.ctorParameters = function () {
        return [];
      };

      EditprofilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-editprofile',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./editprofile.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/editprofile/editprofile.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./editprofile.page.scss */
        "./src/app/pages/editprofile/editprofile.page.scss"))["default"]]
      })], EditprofilePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-editprofile-editprofile-module-es5.js.map