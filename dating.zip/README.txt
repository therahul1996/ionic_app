## INSTALLATION

1. Extract zip file. ex. d:\dating
2. Open Cli, go to the visio folder. ex. cd d:\dating
3. Type npm install
4. Type ionic serve to see.