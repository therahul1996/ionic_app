import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BlockeduserPageRoutingModule } from './blockeduser-routing.module';

import { BlockeduserPage } from './blockeduser.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BlockeduserPageRoutingModule
  ],
  declarations: [BlockeduserPage]
})
export class BlockeduserPageModule {}
