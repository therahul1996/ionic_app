(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-chat-chat-module"], {
    /***/
    "./node_modules/ngx-autosize/__ivy_ngcc__/fesm2015/ngx-autosize.js":
    /*!*************************************************************************!*\
      !*** ./node_modules/ngx-autosize/__ivy_ngcc__/fesm2015/ngx-autosize.js ***!
      \*************************************************************************/

    /*! exports provided: AutosizeDirective, AutosizeModule */

    /***/
    function node_modulesNgxAutosize__ivy_ngcc__Fesm2015NgxAutosizeJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AutosizeDirective", function () {
        return AutosizeDirective;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AutosizeModule", function () {
        return AutosizeModule;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /** @type {?} */


      var MAX_LOOKUP_RETRIES = 3;

      var AutosizeDirective = /*#__PURE__*/function () {
        /**
         * @param {?} element
         * @param {?} _zone
         */
        function AutosizeDirective(element, _zone) {
          _classCallCheck(this, AutosizeDirective);

          this.element = element;
          this._zone = _zone;
          this.onlyGrow = false;
          this.useImportant = false;
          this.resized = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["EventEmitter"]();
          this.retries = 0;
          this._destroyed = false;

          if (this.element.nativeElement.tagName !== 'TEXTAREA') {
            this._findNestedTextArea();
          } else {
            this.textAreaEl = this.element.nativeElement;
            this.textAreaEl.style.overflow = 'hidden';

            this._onTextAreaFound();
          }
        }
        /**
         * @param {?} value
         * @return {?}
         */


        _createClass(AutosizeDirective, [{
          key: "onInput",

          /**
           * @param {?} textArea
           * @return {?}
           */
          value: function onInput(textArea) {
            this.adjust();
          }
          /**
           * @return {?}
           */

        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            this._destroyed = true;

            if (this._windowResizeHandler) {
              window.removeEventListener('resize', this._windowResizeHandler, false);
            }
          }
          /**
           * @return {?}
           */

        }, {
          key: "ngAfterContentChecked",
          value: function ngAfterContentChecked() {
            this.adjust();
          }
          /**
           * @param {?} changes
           * @return {?}
           */

        }, {
          key: "ngOnChanges",
          value: function ngOnChanges(changes) {
            this.adjust(true);
          }
          /**
           * @return {?}
           */

        }, {
          key: "_findNestedTextArea",
          value: function _findNestedTextArea() {
            var _this = this;

            this.textAreaEl = this.element.nativeElement.querySelector('TEXTAREA');

            if (!this.textAreaEl && this.element.nativeElement.shadowRoot) {
              this.textAreaEl = this.element.nativeElement.shadowRoot.querySelector('TEXTAREA');
            }

            if (!this.textAreaEl) {
              if (this.retries >= MAX_LOOKUP_RETRIES) {
                console.warn('ngx-autosize: textarea not found');
              } else {
                this.retries++;
                setTimeout(
                /**
                * @return {?}
                */
                function () {
                  _this._findNestedTextArea();
                }, 100);
              }

              return;
            }

            this.textAreaEl.style.overflow = 'hidden';

            this._onTextAreaFound();
          }
          /**
           * @return {?}
           */

        }, {
          key: "_onTextAreaFound",
          value: function _onTextAreaFound() {
            var _this2 = this;

            this._addWindowResizeHandler();

            setTimeout(
            /**
            * @return {?}
            */
            function () {
              _this2.adjust();
            });
          }
          /**
           * @return {?}
           */

        }, {
          key: "_addWindowResizeHandler",
          value: function _addWindowResizeHandler() {
            var _this3 = this;

            this._windowResizeHandler = Debounce(
            /**
            * @return {?}
            */
            function () {
              _this3._zone.run(
              /**
              * @return {?}
              */
              function () {
                _this3.adjust();
              });
            }, 200);

            this._zone.runOutsideAngular(
            /**
            * @return {?}
            */
            function () {
              window.addEventListener('resize', _this3._windowResizeHandler, false);
            });
          }
          /**
           * @param {?=} inputsChanged
           * @return {?}
           */

        }, {
          key: "adjust",
          value: function adjust() {
            var inputsChanged = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

            if (!this._destroyed && this.textAreaEl) {
              /** @type {?} */
              var currentText = this.textAreaEl.value;

              if (inputsChanged === false && currentText === this._oldContent && this.textAreaEl.offsetWidth === this._oldWidth) {
                return;
              }

              this._oldContent = currentText;
              this._oldWidth = this.textAreaEl.offsetWidth;
              /** @type {?} */

              var clone = this.textAreaEl.cloneNode(true);
              /** @type {?} */

              var parent = this.textAreaEl.parentNode;
              clone.style.width = this.textAreaEl.offsetWidth + 'px';
              clone.style.visibility = 'hidden';
              clone.style.position = 'absolute';
              clone.textContent = currentText;
              parent.appendChild(clone);
              clone.style.overflow = 'hidden';
              clone.style.height = 'auto';
              /** @type {?} */

              var height = clone.scrollHeight; // add into height top and bottom borders' width

              /** @type {?} */

              var computedStyle = window.getComputedStyle(clone, null);
              height += parseInt(computedStyle.getPropertyValue('border-top-width'));
              height += parseInt(computedStyle.getPropertyValue('border-bottom-width'));
              /** @type {?} */

              var oldHeight = this.textAreaEl.offsetHeight;
              /** @type {?} */

              var willGrow = height > oldHeight;

              if (this.onlyGrow === false || willGrow) {
                /** @type {?} */
                var lineHeight = this._getLineHeight();
                /** @type {?} */


                var rowsCount = height / lineHeight;

                if (this._minRows && this._minRows >= rowsCount) {
                  height = this._minRows * lineHeight;
                } else if (this.maxRows && this.maxRows <= rowsCount) {
                  // never shrink the textarea if onlyGrow is true

                  /** @type {?} */
                  var maxHeight = this.maxRows * lineHeight;
                  height = this.onlyGrow ? Math.max(maxHeight, oldHeight) : maxHeight;
                  this.textAreaEl.style.overflow = 'auto';
                } else {
                  this.textAreaEl.style.overflow = 'hidden';
                }
                /** @type {?} */


                var heightStyle = height + 'px';
                /** @type {?} */

                var important = this.useImportant ? 'important' : '';
                this.textAreaEl.style.setProperty('height', heightStyle, important);
                this.resized.emit(height);
              }

              parent.removeChild(clone);
            }
          }
          /**
           * @private
           * @return {?}
           */

        }, {
          key: "_getLineHeight",
          value: function _getLineHeight() {
            /** @type {?} */
            var lineHeight = parseInt(this.textAreaEl.style.lineHeight, 10);

            if (isNaN(lineHeight) && window.getComputedStyle) {
              /** @type {?} */
              var styles = window.getComputedStyle(this.textAreaEl);
              lineHeight = parseInt(styles.lineHeight, 10);
            }

            if (isNaN(lineHeight)) {
              /** @type {?} */
              var fontSize = window.getComputedStyle(this.textAreaEl, null).getPropertyValue('font-size');
              lineHeight = Math.floor(parseInt(fontSize.replace('px', ''), 10) * 1.5);
            }

            return lineHeight;
          }
        }, {
          key: "minRows",
          set: function set(value) {
            this._minRows = value;

            if (this.textAreaEl) {
              this.textAreaEl.rows = value;
            }
          }
        }]);

        return AutosizeDirective;
      }();

      AutosizeDirective.ɵfac = function AutosizeDirective_Factory(t) {
        return new (t || AutosizeDirective)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdirectiveInject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]));
      };

      AutosizeDirective.ɵdir = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineDirective"]({
        type: AutosizeDirective,
        selectors: [["", "autosize", ""]],
        hostBindings: function AutosizeDirective_HostBindings(rf, ctx) {
          if (rf & 1) {
            _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵlistener"]("input", function AutosizeDirective_input_HostBindingHandler($event) {
              return ctx.onInput($event.target);
            });
          }
        },
        inputs: {
          onlyGrow: "onlyGrow",
          useImportant: "useImportant",
          minRows: "minRows",
          maxRows: "maxRows"
        },
        outputs: {
          resized: "resized"
        },
        features: [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵNgOnChangesFeature"]]
      });
      /** @nocollapse */

      AutosizeDirective.ctorParameters = function () {
        return [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
        }];
      };

      AutosizeDirective.propDecorators = {
        minRows: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        maxRows: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        onlyGrow: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        useImportant: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
        }],
        resized: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
        }],
        onInput: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
          args: ['input', ['$event.target']]
        }]
      };
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AutosizeDirective, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Directive"],
          args: [{
            selector: '[autosize]'
          }]
        }], function () {
          return [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["ElementRef"]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
          }];
        }, {
          onlyGrow: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
          }],
          useImportant: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
          }],
          resized: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Output"]
          }],
          minRows: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
          }],

          /**
           * @param {?} textArea
           * @return {?}
           */
          onInput: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["HostListener"],
            args: ['input', ['$event.target']]
          }],
          maxRows: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Input"]
          }]
        });
      })();

      if (false) {}
      /**
       * @param {?} func
       * @param {?} wait
       * @param {?=} immediate
       * @return {?}
       */


      function Debounce(func, wait) {
        var immediate = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;

        /** @type {?} */
        var timeout;
        return (
          /**
          * @return {?}
          */
          function () {
            /** @type {?} */
            var context = this;
            /** @type {?} */

            var args = arguments;
            /** @type {?} */

            var later =
            /**
            * @return {?}
            */
            function later() {
              timeout = null;

              if (!immediate) {
                func.apply(context, args);
              }
            };
            /** @type {?} */


            var callNow = immediate && !timeout;
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);

            if (callNow) {
              func.apply(context, args);
            }
          }
        );
      }
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */


      var AutosizeModule = function AutosizeModule() {
        _classCallCheck(this, AutosizeModule);
      };

      AutosizeModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: AutosizeModule
      });
      AutosizeModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function AutosizeModule_Factory(t) {
          return new (t || AutosizeModule)();
        },
        imports: [[]]
      });

      (function () {
        (typeof ngJitMode === "undefined" || ngJitMode) && _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵsetNgModuleScope"](AutosizeModule, {
          declarations: [AutosizeDirective],
          exports: [AutosizeDirective]
        });
      })();
      /*@__PURE__*/


      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AutosizeModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            declarations: [AutosizeDirective],
            imports: [],
            exports: [AutosizeDirective]
          }]
        }], null, null);
      })();
      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /**
       * @fileoverview added by tsickle
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */
      //# sourceMappingURL=ngx-autosize.js.map

      /***/

    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/chat/chat.page.html":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/chat/chat.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesChatChatPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n\t<ion-toolbar color=\"danger\">\n\t\t<ion-buttons slot=\"start\">\n\t\t\t<ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/discover\"></ion-back-button>\n\t\t</ion-buttons>\n\t\t<ion-title> <b>Emma stone</b> \n\t\t\t<br> \n\t\t<span class=\"small\">Active now</span>\n\t\t</ion-title>\n\t</ion-toolbar>\n</ion-header>\n\n<ion-content [scrollEvents]=\"true\">\n\t<ion-grid>\n\t\t<ion-row *ngFor=\"let message of messages\">\n\t\t\t<ion-col size=\"9\" *ngIf=\"currentUser !== message.user\" class=\"message other-message\">\n\t\t\t\t<b>{{ message.user }}</b><br>\n\t\t\t\t<span>{{ message.msg }}</span>\n\t\t\t\t<div class=\"time ion-text-right\">{{ message.createdAt | date:'short' }}</div>\n\t\t\t</ion-col>\n\t\t\t<ion-col offset=\"3\" size=\"9\" *ngIf=\"currentUser === message.user\" class=\"message my-message\">\n\t\t\t\t<b>{{ message.user }}</b><br>\n\t\t\t\t<span>{{ message.msg }}</span>\n\t\t\t\t<div class=\"time ion-text-right\">{{ message.createdAt | date:'short' }}</div>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t</ion-grid>\n</ion-content>\n<ion-footer class=\"ion-no-border\">\n\t<ion-toolbar color=\"light\">\n\t\t<ion-row>\n\t\t\t<ion-col size=\"10\">\n\t\t\t\t<ion-textarea maxRows=\"3\" autosize [(ngModel)]=\"newMsg\" class=\"message-input\">\n\t\t\t\t</ion-textarea>\n\t\t\t</ion-col>\n\t\t\t<ion-col size=\"2\" class=\"ion-align-self-center\">\n\t\t\t\t<ion-button fill=\"clear\" expand=\"block\" color=\"primary\" [disabled]=\"newMsg === ''\" class=\"msg-btn\" (click)=\"sendMessage()\">\n\t\t\t\t\t<ion-icon name=\"paper-plane-sharp\" slot=\"icon-only\"></ion-icon>\n\t\t\t\t</ion-button>\n\t\t\t</ion-col>\n\t\t</ion-row>\n\t</ion-toolbar>\n</ion-footer>\n";
      /***/
    },

    /***/
    "./src/app/pages/chat/chat-routing.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/pages/chat/chat-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: ChatPageRoutingModule */

    /***/
    function srcAppPagesChatChatRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatPageRoutingModule", function () {
        return ChatPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _chat_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./chat.page */
      "./src/app/pages/chat/chat.page.ts");

      var routes = [{
        path: '',
        component: _chat_page__WEBPACK_IMPORTED_MODULE_3__["ChatPage"]
      }];

      var ChatPageRoutingModule = function ChatPageRoutingModule() {
        _classCallCheck(this, ChatPageRoutingModule);
      };

      ChatPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ChatPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/chat/chat.module.ts":
    /*!*******************************************!*\
      !*** ./src/app/pages/chat/chat.module.ts ***!
      \*******************************************/

    /*! exports provided: ChatPageModule */

    /***/
    function srcAppPagesChatChatModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatPageModule", function () {
        return ChatPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _chat_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./chat-routing.module */
      "./src/app/pages/chat/chat-routing.module.ts");
      /* harmony import */


      var _chat_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./chat.page */
      "./src/app/pages/chat/chat.page.ts");
      /* harmony import */


      var ngx_autosize__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ngx-autosize */
      "./node_modules/ngx-autosize/__ivy_ngcc__/fesm2015/ngx-autosize.js");

      var ChatPageModule = function ChatPageModule() {
        _classCallCheck(this, ChatPageModule);
      };

      ChatPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _chat_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChatPageRoutingModule"], ngx_autosize__WEBPACK_IMPORTED_MODULE_7__["AutosizeModule"]],
        declarations: [_chat_page__WEBPACK_IMPORTED_MODULE_6__["ChatPage"]]
      })], ChatPageModule);
      /***/
    },

    /***/
    "./src/app/pages/chat/chat.page.scss":
    /*!*******************************************!*\
      !*** ./src/app/pages/chat/chat.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesChatChatPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".message {\n  padding: 10px;\n  border-radius: 10px;\n  margin-bottom: 5px;\n  white-space: pre-wrap;\n}\n\n.other-message {\n  background: var(--ion-color-danger);\n  color: #ffffff;\n}\n\n.my-message {\n  background: var(--ion-color-primary);\n  color: #ffffff;\n}\n\n.time {\n  color: #dfdfdf;\n  font-size: small;\n}\n\n.message-input {\n  border: 1px solid var(--ion-color-primary);\n  margin: 0;\n  border-radius: 5px;\n}\n\n.msg-btn {\n  font-size: 16px;\n  --padding-start: 0.5em;\n  --padding-end: 0.5em;\n}\n\n.small {\n  font-size: small;\n}\n\nion-content {\n  --background: #edeef1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2hhdC9jaGF0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUFDRjs7QUFDQTtFQUNFLG1DQUFBO0VBQ0EsY0FBQTtBQUVGOztBQUFBO0VBQ0Usb0NBQUE7RUFDQSxjQUFBO0FBR0Y7O0FBREE7RUFDRSxjQUFBO0VBQ0EsZ0JBQUE7QUFJRjs7QUFGQTtFQUNFLDBDQUFBO0VBQ0EsU0FBQTtFQUNBLGtCQUFBO0FBS0Y7O0FBSEE7RUFDRSxlQUFBO0VBQ0Esc0JBQUE7RUFDQSxvQkFBQTtBQU1GOztBQUpBO0VBQ0UsZ0JBQUE7QUFPRjs7QUFMQTtFQUNFLHFCQUFBO0FBUUYiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9jaGF0L2NoYXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1lc3NhZ2Uge1xuICBwYWRkaW5nOiAxMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiA1cHg7XG4gIHdoaXRlLXNwYWNlOiBwcmUtd3JhcDtcbn1cbi5vdGhlci1tZXNzYWdlIHtcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhbmdlcik7XG4gIGNvbG9yOiAjZmZmZmZmO1xufVxuLm15LW1lc3NhZ2Uge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XG4gIGNvbG9yOiAjZmZmZmZmO1xufVxuLnRpbWUge1xuICBjb2xvcjogI2RmZGZkZjtcbiAgZm9udC1zaXplOiBzbWFsbDtcbn1cbi5tZXNzYWdlLWlucHV0IHtcbiAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICBtYXJnaW46IDA7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cbi5tc2ctYnRuIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDAuNWVtO1xuICAtLXBhZGRpbmctZW5kOiAwLjVlbTtcbn1cbi5zbWFsbCB7XG4gIGZvbnQtc2l6ZTogc21hbGw7XG59XG5pb24tY29udGVudCB7XG4gIC0tYmFja2dyb3VuZDogI2VkZWVmMTtcbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/chat/chat.page.ts":
    /*!*****************************************!*\
      !*** ./src/app/pages/chat/chat.page.ts ***!
      \*****************************************/

    /*! exports provided: ChatPage */

    /***/
    function srcAppPagesChatChatPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChatPage", function () {
        return ChatPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var ChatPage = /*#__PURE__*/function () {
        function ChatPage(navCtrl) {
          _classCallCheck(this, ChatPage);

          this.navCtrl = navCtrl;
          this.messages = [{
            user: 'Srijaul',
            createdAt: 1554090956000,
            msg: 'Hey buddy whatsup?'
          }, {
            user: 'Oishi',
            createdAt: 1554090956000,
            msg: 'I am doing fine you?'
          }, {
            user: 'Srijaul',
            createdAt: 1554090956000,
            msg: 'Same here'
          }];
          this.newMsg = '';
          this.currentUser = 'Srijaul';
        }

        _createClass(ChatPage, [{
          key: "sendMessage",
          value: function sendMessage() {
            var _this4 = this;

            this.messages.push({
              user: 'Srijaul',
              createdAt: new Date().getTime(),
              msg: this.newMsg
            });
            this.newMsg = '';
            setTimeout(function () {
              _this4.content.scrollToBottom(200);
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ChatPage;
      }();

      ChatPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
        }];
      };

      ChatPage.propDecorators = {
        content: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"]]
        }]
      };
      ChatPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-chat',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./chat.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/chat/chat.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./chat.page.scss */
        "./src/app/pages/chat/chat.page.scss"))["default"]]
      })], ChatPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-chat-chat-module-es5.js.map