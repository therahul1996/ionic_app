import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ChangegenderPage } from './changegender.page';

const routes: Routes = [
  {
    path: '',
    component: ChangegenderPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ChangegenderPageRoutingModule {}
