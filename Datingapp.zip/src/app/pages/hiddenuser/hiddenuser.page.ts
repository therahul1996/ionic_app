import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hiddenuser',
  templateUrl: './hiddenuser.page.html',
  styleUrls: ['./hiddenuser.page.scss'],
})
export class HiddenuserPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
