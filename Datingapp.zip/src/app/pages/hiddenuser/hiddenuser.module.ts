import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { HiddenuserPageRoutingModule } from './hiddenuser-routing.module';

import { HiddenuserPage } from './hiddenuser.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    HiddenuserPageRoutingModule
  ],
  declarations: [HiddenuserPage]
})
export class HiddenuserPageModule {}
