(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-hiddenuser-hiddenuser-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hiddenuser/hiddenuser.page.html":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hiddenuser/hiddenuser.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesHiddenuserHiddenuserPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/profile\"></ion-back-button>\n    </ion-buttons>\n    <ion-title> Hidden User</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <ion-row>\n    <ion-col size=\"6\">\n      <ion-card mode=\"ios\" routerLink=\"/userdetails\" routerDirection=\"root\">\n        <ion-card-header>\n          <img src=\"../../../assets/img/girl1.jpg\" alt=\"\">\n        </ion-card-header>\n        <ion-card-content>\n          <div class=\"gmi\">\n            <span></span>\n            <ion-label>Emma Stone</ion-label>\n          </div>\n          <p>19, Torento</p>\n          <div class=\"country\">\n            <ion-label>\n              Canada\n            </ion-label>\n            <img src=\"../../../assets/img/flag/canada.jpg\" alt=\"\">\n\n          </div>\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n  </ion-row>\n\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/hiddenuser/hiddenuser-routing.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/pages/hiddenuser/hiddenuser-routing.module.ts ***!
      \***************************************************************/

    /*! exports provided: HiddenuserPageRoutingModule */

    /***/
    function srcAppPagesHiddenuserHiddenuserRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HiddenuserPageRoutingModule", function () {
        return HiddenuserPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _hiddenuser_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./hiddenuser.page */
      "./src/app/pages/hiddenuser/hiddenuser.page.ts");

      var routes = [{
        path: '',
        component: _hiddenuser_page__WEBPACK_IMPORTED_MODULE_3__["HiddenuserPage"]
      }];

      var HiddenuserPageRoutingModule = function HiddenuserPageRoutingModule() {
        _classCallCheck(this, HiddenuserPageRoutingModule);
      };

      HiddenuserPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HiddenuserPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/hiddenuser/hiddenuser.module.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/hiddenuser/hiddenuser.module.ts ***!
      \*******************************************************/

    /*! exports provided: HiddenuserPageModule */

    /***/
    function srcAppPagesHiddenuserHiddenuserModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HiddenuserPageModule", function () {
        return HiddenuserPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _hiddenuser_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./hiddenuser-routing.module */
      "./src/app/pages/hiddenuser/hiddenuser-routing.module.ts");
      /* harmony import */


      var _hiddenuser_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./hiddenuser.page */
      "./src/app/pages/hiddenuser/hiddenuser.page.ts");

      var HiddenuserPageModule = function HiddenuserPageModule() {
        _classCallCheck(this, HiddenuserPageModule);
      };

      HiddenuserPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _hiddenuser_routing_module__WEBPACK_IMPORTED_MODULE_5__["HiddenuserPageRoutingModule"]],
        declarations: [_hiddenuser_page__WEBPACK_IMPORTED_MODULE_6__["HiddenuserPage"]]
      })], HiddenuserPageModule);
      /***/
    },

    /***/
    "./src/app/pages/hiddenuser/hiddenuser.page.scss":
    /*!*******************************************************!*\
      !*** ./src/app/pages/hiddenuser/hiddenuser.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesHiddenuserHiddenuserPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background: #edeef1;\n}\n\nion-card {\n  margin: 0 0 15px 0;\n}\n\nion-card ion-card-header {\n  padding: 0;\n}\n\nion-card ion-card-header img {\n  height: 100px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  width: 100%;\n}\n\nion-card-header + .card-content-ios {\n  padding: 15px 10px 10px 10px;\n}\n\nion-card-header + .card-content-ios .gmi {\n  display: flex;\n  align-items: center;\n  margin-bottom: 0.5rem;\n}\n\nion-card-header + .card-content-ios .gmi span {\n  height: 10px;\n  width: 10px;\n  display: block;\n  background-color: greenyellow;\n  border-radius: 50%;\n  margin-right: 10px;\n}\n\nion-card-header + .card-content-ios p {\n  margin-bottom: 0.5rem;\n}\n\nion-card-header + .card-content-ios .country {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\nion-card-header + .card-content-ios .country img {\n  height: 15px;\n  margin-left: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaGlkZGVudXNlci9oaWRkZW51c2VyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtBQUNKOztBQUNJO0VBQ0ksVUFBQTtBQUNSOztBQUNRO0VBQ0ksYUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSxXQUFBO0FBQ1o7O0FBSUE7RUFDSSw0QkFBQTtBQURKOztBQUdJO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7QUFEUjs7QUFHUTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsY0FBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQURaOztBQU9JO0VBQ0kscUJBQUE7QUFMUjs7QUFRSTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FBTlI7O0FBUVE7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7QUFOWiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2hpZGRlbnVzZXIvaGlkZGVudXNlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNlZGVlZjE7XHJcbn1cclxuXHJcbmlvbi1jYXJkIHtcclxuICAgIG1hcmdpbjogMCAwIDE1cHggMDtcclxuXHJcbiAgICBpb24tY2FyZC1oZWFkZXIge1xyXG4gICAgICAgIHBhZGRpbmc6IDA7XHJcblxyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbmlvbi1jYXJkLWhlYWRlcisuY2FyZC1jb250ZW50LWlvcyB7XHJcbiAgICBwYWRkaW5nOiAxNXB4IDEwcHggMTBweCAxMHB4O1xyXG5cclxuICAgIC5nbWkge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAuNXJlbTtcclxuXHJcbiAgICAgICAgc3BhbiB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTBweDtcclxuICAgICAgICAgICAgd2lkdGg6IDEwcHg7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbnllbGxvdztcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG5cclxuXHJcbiAgICB9XHJcblxyXG4gICAgcCB7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogLjVyZW07XHJcbiAgICB9XHJcblxyXG4gICAgLmNvdW50cnkge1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcblxyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgIGhlaWdodDogMTVweDtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDE1cHhcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/pages/hiddenuser/hiddenuser.page.ts":
    /*!*****************************************************!*\
      !*** ./src/app/pages/hiddenuser/hiddenuser.page.ts ***!
      \*****************************************************/

    /*! exports provided: HiddenuserPage */

    /***/
    function srcAppPagesHiddenuserHiddenuserPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HiddenuserPage", function () {
        return HiddenuserPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var HiddenuserPage = /*#__PURE__*/function () {
        function HiddenuserPage() {
          _classCallCheck(this, HiddenuserPage);
        }

        _createClass(HiddenuserPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return HiddenuserPage;
      }();

      HiddenuserPage.ctorParameters = function () {
        return [];
      };

      HiddenuserPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-hiddenuser',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./hiddenuser.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/hiddenuser/hiddenuser.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./hiddenuser.page.scss */
        "./src/app/pages/hiddenuser/hiddenuser.page.scss"))["default"]]
      })], HiddenuserPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-hiddenuser-hiddenuser-module-es5.js.map