import { Component, OnInit } from '@angular/core';
// import { IonToggle, ModalController } from '@ionic/angular';
// import { ViewerModalComponent } from 'ngx-ionic-image-viewer';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.page.html',
  styleUrls: ['./userdetails.page.scss'],
})
export class UserdetailsPage implements OnInit {

  // imgUrl = `../../../assets/img/girl1.jpg`;

  constructor() { }
  // slideOpts = {
  //   initialSlide: 0,
  //   slidesPerView: 1,
  //   autoplay: true,
  //   pagination: {
  //     el: '.swiper-pagination',
  //     type: 'fraction',
  //   }
  // };
  ngOnInit() {
  }
  // constructor(public modalController: ModalController) { }
  // async openViewer() {
  //   const modal = await this.modalController.create({
  //     component: ViewerModalComponent,
  //     componentProps: {
  //       src: this.imgUrl,
  //     },
  //     cssClass: 'ion-img-viewer',
  //     keyboardClose: true,
  //     showBackdrop: true,
  //   });

  //   return await modal.present();
  // }
}
