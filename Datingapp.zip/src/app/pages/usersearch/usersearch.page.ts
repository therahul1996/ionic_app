import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usersearch',
  templateUrl: './usersearch.page.html',
  styleUrls: ['./usersearch.page.scss'],
})
export class UsersearchPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
