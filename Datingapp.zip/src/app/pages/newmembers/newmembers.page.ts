import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { FiltermodalPage } from '../filtermodal/filtermodal.page';
@Component({
  selector: 'app-newmembers',
  templateUrl: './newmembers.page.html',
  styleUrls: ['./newmembers.page.scss'],
})
export class NewmembersPage implements OnInit {


  constructor(public modalController: ModalController) { }

  ngOnInit() {
  }
  async presentModal() {
    const modal = await this.modalController.create({
      component: FiltermodalPage,
      cssClass: 'my-custom-class'
    });
    return await modal.present();
  }
}
