import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { HiddenuserPage } from './hiddenuser.page';

describe('HiddenuserPage', () => {
  let component: HiddenuserPage;
  let fixture: ComponentFixture<HiddenuserPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HiddenuserPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(HiddenuserPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
