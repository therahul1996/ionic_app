(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-viewprofile-viewprofile-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/viewprofile/viewprofile.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/viewprofile/viewprofile.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/profile\"></ion-back-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-no-padding\">\n  <div class=\"cover_img\">\n    <img src=\"../../../assets/img/girl1.jpg\" alt=\"\">\n    <!-- <ion-icon name=\"camera-outline\"></ion-icon> -->\n  </div>\n  <div class=\"profile_img\">\n    <img src=\"../../../assets/img/girl5.jpg\" alt=\"\">\n    <!-- <ion-icon name=\"camera-outline\"></ion-icon> -->\n  </div>\n\n  <ion-row class=\"ion-margin-horizontal\">\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <h2 class=\"mb-0 mt-0\">Emilly Jones</h2>\n      <small class=\"text-green\">Active now</small>\n      <p>Hi there I'm Emilly from Michigan. I wish i will find someone here </p>\n    </ion-col>\n  </ion-row>\n  <ion-list class=\"userdel-list\">\n    <ion-row>\n      <ion-col size=\"12\">\n        <p>22, Never Married</p>\n        <p>Michigan,USA</p>\n        <p>Christian-Orthodox</p>\n        <p>Looking for: Men</p>\n      </ion-col>\n    </ion-row>\n  </ion-list>\n  <ion-card>\n    <ion-card-header style=\"background: #d0d0d0;\">\n      <ion-label>Verifications</ion-label>\n    </ion-card-header>\n    <ion-card-content>\n      <ion-item>\n        <ion-icon Slot=\"start\" name=\"logo-facebook\"></ion-icon>\n        <ion-label>1453 Friends, Birthday verified</ion-label>\n      </ion-item>\n    </ion-card-content>\n  </ion-card>\n  <ion-card>\n    <ion-card-content>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-label>Country of origin</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>Canada</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Languages</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>English, Spanish</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Ethncity</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>Canadian</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Height / Weight</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>167cm / 55kg</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Body Type</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>Athletic</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Has Children</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>No</ion-label>\n        </ion-col>\n      </ion-row>\n    </ion-card-content>\n  </ion-card>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/viewprofile/viewprofile-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/viewprofile/viewprofile-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: ViewprofilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewprofilePageRoutingModule", function() { return ViewprofilePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _viewprofile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./viewprofile.page */ "./src/app/pages/viewprofile/viewprofile.page.ts");




const routes = [
    {
        path: '',
        component: _viewprofile_page__WEBPACK_IMPORTED_MODULE_3__["ViewprofilePage"]
    }
];
let ViewprofilePageRoutingModule = class ViewprofilePageRoutingModule {
};
ViewprofilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ViewprofilePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/viewprofile/viewprofile.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/viewprofile/viewprofile.module.ts ***!
  \*********************************************************/
/*! exports provided: ViewprofilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewprofilePageModule", function() { return ViewprofilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _viewprofile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./viewprofile-routing.module */ "./src/app/pages/viewprofile/viewprofile-routing.module.ts");
/* harmony import */ var _viewprofile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./viewprofile.page */ "./src/app/pages/viewprofile/viewprofile.page.ts");







let ViewprofilePageModule = class ViewprofilePageModule {
};
ViewprofilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _viewprofile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ViewprofilePageRoutingModule"]
        ],
        declarations: [_viewprofile_page__WEBPACK_IMPORTED_MODULE_6__["ViewprofilePage"]]
    })
], ViewprofilePageModule);



/***/ }),

/***/ "./src/app/pages/viewprofile/viewprofile.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/viewprofile/viewprofile.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #f4f5f8;\n}\n\n.dflex {\n  font-size: 2rem;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.dflex ion-icon {\n  padding: 0 10px;\n}\n\n.userdel-list {\n  padding: 0 16px;\n  background: transparent;\n}\n\n.userdel-list p {\n  margin: 0;\n  color: #675e5b;\n  font-size: 13px;\n  line-height: 1.3;\n  font-weight: 500;\n}\n\n.cover_img {\n  height: 190px;\n  width: 100%;\n  position: relative;\n}\n\n.cover_img img {\n  height: 100%;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\n.cover_img ion-icon {\n  font-size: 1.4rem;\n  background: #ccc;\n  padding: 8px;\n  border-radius: 50%;\n  position: absolute;\n  right: 20px;\n  bottom: 15px;\n  border: 1px solid #ccc;\n}\n\n.profile_img {\n  height: 150px;\n  width: 150px;\n  margin: 0 auto;\n  margin-top: -75px;\n  position: relative;\n}\n\n.profile_img img {\n  height: 100%;\n  width: 100%;\n  border: 5px solid #ffffff;\n  border-radius: 50%;\n}\n\n.profile_img ion-icon {\n  font-size: 1.4rem;\n  background: #ccc;\n  padding: 8px;\n  border-radius: 50%;\n  position: absolute;\n  right: 0;\n  bottom: 15px;\n  border: 1px solid #ccc;\n}\n\n.text-green {\n  color: var(--ion-color-success);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdmlld3Byb2ZpbGUvdmlld3Byb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUNKOztBQUNJO0VBQ0ksZUFBQTtBQUNSOztBQUdBO0VBQ0ksZUFBQTtFQUNBLHVCQUFBO0FBQUo7O0FBRUk7RUFDSSxTQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FBQVI7O0FBSUE7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBREo7O0FBR0k7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUFEUjs7QUFJSTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUFGUjs7QUFNQTtFQUNJLGFBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFISjs7QUFLSTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQUhSOztBQU1JO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQUpSOztBQVFBO0VBQ0ksK0JBQUE7QUFMSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL3ZpZXdwcm9maWxlL3ZpZXdwcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogI2Y0ZjVmODtcclxufVxyXG5cclxuLmRmbGV4IHtcclxuICAgIGZvbnQtc2l6ZTogMnJlbTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblxyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICAgIHBhZGRpbmc6IDAgMTBweDtcclxuICAgIH1cclxufVxyXG5cclxuLnVzZXJkZWwtbGlzdCB7XHJcbiAgICBwYWRkaW5nOiAwIDE2cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuXHJcbiAgICBwIHtcclxuICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgY29sb3I6ICM2NzVlNWI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxLjM7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIH1cclxufVxyXG5cclxuLmNvdmVyX2ltZyB7XHJcbiAgICBoZWlnaHQ6IDE5MHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgaW1nIHtcclxuICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMS40cmVtO1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNjY2M7XHJcbiAgICAgICAgcGFkZGluZzogOHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgcmlnaHQ6IDIwcHg7XHJcbiAgICAgICAgYm90dG9tOiAxNXB4O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wcm9maWxlX2ltZyB7XHJcbiAgICBoZWlnaHQ6IDE1MHB4O1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAtNzVweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICBpbWcge1xyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBib3JkZXI6IDVweCBzb2xpZCAjZmZmZmZmO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIH1cclxuXHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxLjRyZW07XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2NjYztcclxuICAgICAgICBwYWRkaW5nOiA4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICByaWdodDogMDtcclxuICAgICAgICBib3R0b206IDE1cHg7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICAgIH1cclxufVxyXG5cclxuLnRleHQtZ3JlZW4ge1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/pages/viewprofile/viewprofile.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/viewprofile/viewprofile.page.ts ***!
  \*******************************************************/
/*! exports provided: ViewprofilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ViewprofilePage", function() { return ViewprofilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let ViewprofilePage = class ViewprofilePage {
    constructor() { }
    ngOnInit() {
    }
};
ViewprofilePage.ctorParameters = () => [];
ViewprofilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-viewprofile',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./viewprofile.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/viewprofile/viewprofile.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./viewprofile.page.scss */ "./src/app/pages/viewprofile/viewprofile.page.scss")).default]
    })
], ViewprofilePage);



/***/ })

}]);
//# sourceMappingURL=pages-viewprofile-viewprofile-module-es2015.js.map