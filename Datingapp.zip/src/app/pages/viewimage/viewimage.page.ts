import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewimage',
  templateUrl: './viewimage.page.html',
  styleUrls: ['./viewimage.page.scss'],
})
export class ViewimagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
