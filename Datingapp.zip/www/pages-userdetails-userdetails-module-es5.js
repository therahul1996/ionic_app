(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-userdetails-userdetails-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/userdetails/userdetails.page.html":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/userdetails/userdetails.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesUserdetailsUserdetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/discover\"></ion-back-button>\n      <!-- <ion-button>\n        <ion-icon slot=\"icon-only\" name=\"chevron-back-outline\"></ion-icon>\n      </ion-button> -->\n    </ion-buttons>\n    <ion-buttons slot=\"secondary\">\n      <ion-button>\n        <ion-icon slot=\"icon-only\" name=\"call-outline\"></ion-icon>\n      </ion-button>\n      <ion-button>\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n      <ion-button>\n        <ion-icon slot=\"icon-only\" name=\"warning-outline\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <!-- <ion-title>Jhon Doe</ion-title> -->\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-no-padding\">\n  <div class=\"cover_img\">\n    <img src=\"../../../assets/img/girl1.jpg\" alt=\"\">\n    <!-- <ion-icon name=\"camera-outline\"></ion-icon> -->\n  </div>\n  <div class=\"profile_img\">\n    <img src=\"../../../assets/img/girl5.jpg\" alt=\"\">\n    <!-- <ion-icon name=\"camera-outline\"></ion-icon> -->\n  </div>\n\n  <ion-row class=\"ion-margin-horizontal\">\n    <ion-col size=\"12\" class=\"ion-text-center\">\n      <h2 class=\"mb-0 mt-0\">Emilly Jones</h2>\n      <small class=\"text-muted\">Active an hour ago</small>\n      <p>Hi there I'm Emilly from Michigan. I wish i will find someone here </p>\n    </ion-col>\n  </ion-row>\n  <ion-list class=\"userdel-list\">\n    <ion-row>\n      <ion-col size=\"6\">\n        <p>22, Never Married</p>\n        <p>Michigan,USA</p>\n        <p>Christian-Orthodox</p>\n        <p>Looking for: Men</p>\n      </ion-col>\n      <ion-col size=\"6\">\n        <ion-row>\n          <ion-col size=\"6\">\n            <ion-button expand=\"block\" fill=\"solid\" color=\"success\">\n              <ion-icon name=\"star-outline\"></ion-icon>\n            </ion-button>\n          </ion-col>\n          <ion-col size=\"6\" routerLink=\"/chat\" routerDirection=\"root\">\n            <ion-button expand=\"block\" fill=\"solid\" color=\"success\">\n              <ion-icon name=\"chatbubbles-outline\"></ion-icon>\n            </ion-button>\n          </ion-col>\n        </ion-row>\n      </ion-col>\n    </ion-row>\n  </ion-list>\n  <ion-card>\n    <ion-card-content>\n      <ion-row>\n        <ion-col size=\"6\">\n          <ion-label>Country of origin</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>Canada</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Languages</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>English, Spanish</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Ethncity</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>Canadian</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Height / Weight</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>167cm / 55kg</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Body Type</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>Athletic</ion-label>\n        </ion-col>\n        <ion-col size=\"6\">\n          <ion-label>Has Children</ion-label>\n        </ion-col>\n        <ion-col size=\"6\" class=\"ion-text-right\">\n          <ion-label>No</ion-label>\n        </ion-col>\n      </ion-row>\n    </ion-card-content>\n  </ion-card>\n\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/userdetails/userdetails-routing.module.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/userdetails/userdetails-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: UserdetailsPageRoutingModule */

    /***/
    function srcAppPagesUserdetailsUserdetailsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UserdetailsPageRoutingModule", function () {
        return UserdetailsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _userdetails_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./userdetails.page */
      "./src/app/pages/userdetails/userdetails.page.ts");

      var routes = [{
        path: '',
        component: _userdetails_page__WEBPACK_IMPORTED_MODULE_3__["UserdetailsPage"]
      }];

      var UserdetailsPageRoutingModule = function UserdetailsPageRoutingModule() {
        _classCallCheck(this, UserdetailsPageRoutingModule);
      };

      UserdetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], UserdetailsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/userdetails/userdetails.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/userdetails/userdetails.module.ts ***!
      \*********************************************************/

    /*! exports provided: UserdetailsPageModule */

    /***/
    function srcAppPagesUserdetailsUserdetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UserdetailsPageModule", function () {
        return UserdetailsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _userdetails_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./userdetails-routing.module */
      "./src/app/pages/userdetails/userdetails-routing.module.ts");
      /* harmony import */


      var _userdetails_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./userdetails.page */
      "./src/app/pages/userdetails/userdetails.page.ts");

      var UserdetailsPageModule = function UserdetailsPageModule() {
        _classCallCheck(this, UserdetailsPageModule);
      };

      UserdetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _userdetails_routing_module__WEBPACK_IMPORTED_MODULE_5__["UserdetailsPageRoutingModule"]],
        declarations: [_userdetails_page__WEBPACK_IMPORTED_MODULE_6__["UserdetailsPage"]]
      })], UserdetailsPageModule);
      /***/
    },

    /***/
    "./src/app/pages/userdetails/userdetails.page.scss":
    /*!*********************************************************!*\
      !*** ./src/app/pages/userdetails/userdetails.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesUserdetailsUserdetailsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background:#f4f5f8;\n}\n\n.dflex {\n  font-size: 2rem;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.dflex ion-icon {\n  padding: 0 10px;\n}\n\n.userdel-list {\n  padding: 0 16px;\n  background: transparent;\n}\n\n.userdel-list p {\n  margin: 0;\n  color: #675e5b;\n  font-size: 13px;\n  line-height: 1.3;\n  font-weight: 500;\n}\n\n.cover_img {\n  height: 190px;\n  width: 100%;\n  position: relative;\n}\n\n.cover_img img {\n  height: 100%;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\n.cover_img ion-icon {\n  font-size: 1.4rem;\n  background: #ccc;\n  padding: 8px;\n  border-radius: 50%;\n  position: absolute;\n  right: 20px;\n  bottom: 15px;\n  border: 1px solid #ccc;\n}\n\n.profile_img {\n  height: 150px;\n  width: 150px;\n  margin: 0 auto;\n  margin-top: -75px;\n  position: relative;\n}\n\n.profile_img img {\n  height: 100%;\n  width: 100%;\n  border: 5px solid #ffffff;\n  border-radius: 50%;\n}\n\n.profile_img ion-icon {\n  font-size: 1.4rem;\n  background: #ccc;\n  padding: 8px;\n  border-radius: 50%;\n  position: absolute;\n  right: 0;\n  bottom: 15px;\n  border: 1px solid #ccc;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvdXNlcmRldGFpbHMvdXNlcmRldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksb0JBQUE7QUFDSjs7QUFDQTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUVKOztBQURJO0VBQ0ksZUFBQTtBQUdSOztBQUFBO0VBQ1EsZUFBQTtFQUNBLHVCQUFBO0FBR1I7O0FBRkk7RUFDRyxTQUFBO0VBQ0MsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0FBSVI7O0FBREE7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBSUo7O0FBSEk7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUFLUjs7QUFISTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUFLUjs7QUFGQTtFQUNJLGFBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFLSjs7QUFKSTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQU1SOztBQUpJO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQU1SIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvdXNlcmRldGFpbHMvdXNlcmRldGFpbHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnR7XHJcbiAgICAtLWJhY2tncm91bmQ6I2Y0ZjVmODtcclxufVxyXG4uZGZsZXh7XHJcbiAgICBmb250LXNpemU6IDJyZW07XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgaW9uLWljb257XHJcbiAgICAgICAgcGFkZGluZzogMCAxMHB4O1xyXG4gICAgfVxyXG59XHJcbi51c2VyZGVsLWxpc3Qge1xyXG4gICAgICAgIHBhZGRpbmc6IDAgMTZweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIHB7XHJcbiAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgY29sb3I6ICM2NzVlNWI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxLjM7XHJcbiAgICAgICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIH1cclxufVxyXG4uY292ZXJfaW1ne1xyXG4gICAgaGVpZ2h0OiAxOTBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgaW1ne1xyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgIH1cclxuICAgIGlvbi1pY29ue1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMS40cmVtO1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNjY2M7XHJcbiAgICAgICAgcGFkZGluZzogOHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgcmlnaHQ6IDIwcHg7XHJcbiAgICAgICAgYm90dG9tOiAxNXB4O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICB9XHJcbn1cclxuLnByb2ZpbGVfaW1ne1xyXG4gICAgaGVpZ2h0OiAxNTBweDtcclxuICAgIHdpZHRoOiAxNTBweDtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDogLTc1cHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBpbWd7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGJvcmRlcjogNXB4IHNvbGlkICNmZmZmZmY7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgfVxyXG4gICAgaW9uLWljb257XHJcbiAgICAgICAgZm9udC1zaXplOiAxLjRyZW07XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2NjYztcclxuICAgICAgICBwYWRkaW5nOiA4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICByaWdodDogMDtcclxuICAgICAgICBib3R0b206IDE1cHg7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICAgIH1cclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/userdetails/userdetails.page.ts":
    /*!*******************************************************!*\
      !*** ./src/app/pages/userdetails/userdetails.page.ts ***!
      \*******************************************************/

    /*! exports provided: UserdetailsPage */

    /***/
    function srcAppPagesUserdetailsUserdetailsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UserdetailsPage", function () {
        return UserdetailsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var UserdetailsPage = /*#__PURE__*/function () {
        function UserdetailsPage() {
          _classCallCheck(this, UserdetailsPage);
        } // slideOpts = {
        //   initialSlide: 0,
        //   slidesPerView: 1,
        //   autoplay: true,
        //   pagination: {
        //     el: '.swiper-pagination',
        //     type: 'fraction',
        //   }
        // };


        _createClass(UserdetailsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return UserdetailsPage;
      }();

      UserdetailsPage.ctorParameters = function () {
        return [];
      };

      UserdetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-userdetails',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./userdetails.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/userdetails/userdetails.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./userdetails.page.scss */
        "./src/app/pages/userdetails/userdetails.page.scss"))["default"]]
      })], UserdetailsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-userdetails-userdetails-module-es5.js.map