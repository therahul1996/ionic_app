(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-changegender-changegender-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/changegender/changegender.page.html":
    /*!*************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/changegender/changegender.page.html ***!
      \*************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesChangegenderChangegenderPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/profile\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Change your Gender</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-label style=\"margin-right: 15px;\">Save</ion-label>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <p class=\"ion-text-center\">Please note you can only change your gender once</p>\n  <ion-segment (ionChange)=\"segmentChanged($event)\" value=\"male\" mode=\"ios\">\n    <ion-segment-button value=\"male\">\n      <ion-label>I am Male</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"female\">\n      <ion-label>I am Female</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/changegender/changegender-routing.module.ts":
    /*!*******************************************************************!*\
      !*** ./src/app/pages/changegender/changegender-routing.module.ts ***!
      \*******************************************************************/

    /*! exports provided: ChangegenderPageRoutingModule */

    /***/
    function srcAppPagesChangegenderChangegenderRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangegenderPageRoutingModule", function () {
        return ChangegenderPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _changegender_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./changegender.page */
      "./src/app/pages/changegender/changegender.page.ts");

      var routes = [{
        path: '',
        component: _changegender_page__WEBPACK_IMPORTED_MODULE_3__["ChangegenderPage"]
      }];

      var ChangegenderPageRoutingModule = function ChangegenderPageRoutingModule() {
        _classCallCheck(this, ChangegenderPageRoutingModule);
      };

      ChangegenderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ChangegenderPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/changegender/changegender.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/changegender/changegender.module.ts ***!
      \***********************************************************/

    /*! exports provided: ChangegenderPageModule */

    /***/
    function srcAppPagesChangegenderChangegenderModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangegenderPageModule", function () {
        return ChangegenderPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _changegender_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./changegender-routing.module */
      "./src/app/pages/changegender/changegender-routing.module.ts");
      /* harmony import */


      var _changegender_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./changegender.page */
      "./src/app/pages/changegender/changegender.page.ts");

      var ChangegenderPageModule = function ChangegenderPageModule() {
        _classCallCheck(this, ChangegenderPageModule);
      };

      ChangegenderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _changegender_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangegenderPageRoutingModule"]],
        declarations: [_changegender_page__WEBPACK_IMPORTED_MODULE_6__["ChangegenderPage"]]
      })], ChangegenderPageModule);
      /***/
    },

    /***/
    "./src/app/pages/changegender/changegender.page.scss":
    /*!***********************************************************!*\
      !*** ./src/app/pages/changegender/changegender.page.scss ***!
      \***********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesChangegenderChangegenderPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background: #f4f5f8;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2hhbmdlZ2VuZGVyL2NoYW5nZWdlbmRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxxQkFBQTtBQUNKIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvY2hhbmdlZ2VuZGVyL2NoYW5nZWdlbmRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNmNGY1Zjg7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/pages/changegender/changegender.page.ts":
    /*!*********************************************************!*\
      !*** ./src/app/pages/changegender/changegender.page.ts ***!
      \*********************************************************/

    /*! exports provided: ChangegenderPage */

    /***/
    function srcAppPagesChangegenderChangegenderPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangegenderPage", function () {
        return ChangegenderPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var ChangegenderPage = /*#__PURE__*/function () {
        function ChangegenderPage() {
          _classCallCheck(this, ChangegenderPage);
        }

        _createClass(ChangegenderPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ChangegenderPage;
      }();

      ChangegenderPage.ctorParameters = function () {
        return [];
      };

      ChangegenderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-changegender',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./changegender.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/changegender/changegender.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./changegender.page.scss */
        "./src/app/pages/changegender/changegender.page.scss"))["default"]]
      })], ChangegenderPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-changegender-changegender-module-es5.js.map