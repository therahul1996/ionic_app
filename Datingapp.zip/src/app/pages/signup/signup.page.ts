import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {

  number: boolean = true;
  email: boolean = false;
  items: any[];

  constructor() { }

  ngOnInit() {
  }
  segmentChanged(ev: any){
    // console.log('Segment changed', ev.detail.value);
    if (ev.detail.value == 'number'){
        this.number = true;
        this.email = false;
    }
    else if (ev.detail.value == 'email'){
      this.email = true;
      this.number = false;
      
    }
  }
}
