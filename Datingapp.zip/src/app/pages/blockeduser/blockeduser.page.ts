import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blockeduser',
  templateUrl: './blockeduser.page.html',
  styleUrls: ['./blockeduser.page.scss'],
})
export class BlockeduserPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
