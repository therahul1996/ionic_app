(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-blockeduser-blockeduser-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/blockeduser/blockeduser.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/blockeduser/blockeduser.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/profile\"></ion-back-button>\n    </ion-buttons>\n    <ion-title> Who am I Blocking</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <ion-row>\n    <ion-col size=\"6\">\n      <ion-card mode=\"ios\" routerLink=\"/userdetails\" routerDirection=\"root\">\n        <ion-card-header>\n          <img src=\"../../../assets/img/girl1.jpg\" alt=\"\">\n        </ion-card-header>\n        <ion-card-content>\n          <div class=\"gmi\">\n            <span></span>\n            <ion-label>Emma Stone</ion-label>\n          </div>\n          <p>19, Torento</p>\n          <div class=\"country\">\n            <ion-label>\n              Canada\n            </ion-label>\n            <img src=\"../../../assets/img/flag/canada.jpg\" alt=\"\">\n\n          </div>\n        </ion-card-content>\n      </ion-card>\n    </ion-col>\n  </ion-row>\n\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/blockeduser/blockeduser-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/pages/blockeduser/blockeduser-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: BlockeduserPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlockeduserPageRoutingModule", function() { return BlockeduserPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _blockeduser_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./blockeduser.page */ "./src/app/pages/blockeduser/blockeduser.page.ts");




const routes = [
    {
        path: '',
        component: _blockeduser_page__WEBPACK_IMPORTED_MODULE_3__["BlockeduserPage"]
    }
];
let BlockeduserPageRoutingModule = class BlockeduserPageRoutingModule {
};
BlockeduserPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], BlockeduserPageRoutingModule);



/***/ }),

/***/ "./src/app/pages/blockeduser/blockeduser.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/blockeduser/blockeduser.module.ts ***!
  \*********************************************************/
/*! exports provided: BlockeduserPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlockeduserPageModule", function() { return BlockeduserPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _blockeduser_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./blockeduser-routing.module */ "./src/app/pages/blockeduser/blockeduser-routing.module.ts");
/* harmony import */ var _blockeduser_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./blockeduser.page */ "./src/app/pages/blockeduser/blockeduser.page.ts");







let BlockeduserPageModule = class BlockeduserPageModule {
};
BlockeduserPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _blockeduser_routing_module__WEBPACK_IMPORTED_MODULE_5__["BlockeduserPageRoutingModule"]
        ],
        declarations: [_blockeduser_page__WEBPACK_IMPORTED_MODULE_6__["BlockeduserPage"]]
    })
], BlockeduserPageModule);



/***/ }),

/***/ "./src/app/pages/blockeduser/blockeduser.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/pages/blockeduser/blockeduser.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #edeef1;\n}\n\nion-card {\n  margin: 0 0 15px 0;\n}\n\nion-card ion-card-header {\n  padding: 0;\n}\n\nion-card ion-card-header img {\n  height: 100px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  width: 100%;\n}\n\nion-card-header + .card-content-ios {\n  padding: 15px 10px 10px 10px;\n}\n\nion-card-header + .card-content-ios .gmi {\n  display: flex;\n  align-items: center;\n  margin-bottom: 0.5rem;\n}\n\nion-card-header + .card-content-ios .gmi span {\n  height: 10px;\n  width: 10px;\n  display: block;\n  background-color: greenyellow;\n  border-radius: 50%;\n  margin-right: 10px;\n}\n\nion-card-header + .card-content-ios p {\n  margin-bottom: 0.5rem;\n}\n\nion-card-header + .card-content-ios .country {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n}\n\nion-card-header + .card-content-ios .country img {\n  height: 15px;\n  margin-left: 15px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYmxvY2tlZHVzZXIvYmxvY2tlZHVzZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0FBQ0o7O0FBQ0k7RUFDSSxVQUFBO0FBQ1I7O0FBQ1E7RUFDSSxhQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLFdBQUE7QUFDWjs7QUFJQTtFQUNJLDRCQUFBO0FBREo7O0FBR0k7RUFDSSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtBQURSOztBQUdRO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxjQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBRFo7O0FBT0k7RUFDSSxxQkFBQTtBQUxSOztBQVFJO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUFOUjs7QUFRUTtFQUNJLFlBQUE7RUFDQSxpQkFBQTtBQU5aIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvYmxvY2tlZHVzZXIvYmxvY2tlZHVzZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZWRlZWYxO1xyXG59XHJcblxyXG5pb24tY2FyZCB7XHJcbiAgICBtYXJnaW46IDAgMCAxNXB4IDA7XHJcblxyXG4gICAgaW9uLWNhcmQtaGVhZGVyIHtcclxuICAgICAgICBwYWRkaW5nOiAwO1xyXG5cclxuICAgICAgICBpbWcge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG5pb24tY2FyZC1oZWFkZXIrLmNhcmQtY29udGVudC1pb3Mge1xyXG4gICAgcGFkZGluZzogMTVweCAxMHB4IDEwcHggMTBweDtcclxuXHJcbiAgICAuZ21pIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogLjVyZW07XHJcblxyXG4gICAgICAgIHNwYW4ge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDEwcHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiAxMHB4O1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW55ZWxsb3c7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgICAgIH1cclxuXHJcblxyXG4gICAgfVxyXG5cclxuICAgIHAge1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IC41cmVtO1xyXG4gICAgfVxyXG5cclxuICAgIC5jb3VudHJ5IHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cclxuICAgICAgICBpbWcge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDE1cHg7XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0OiAxNXB4XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */");

/***/ }),

/***/ "./src/app/pages/blockeduser/blockeduser.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/pages/blockeduser/blockeduser.page.ts ***!
  \*******************************************************/
/*! exports provided: BlockeduserPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BlockeduserPage", function() { return BlockeduserPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let BlockeduserPage = class BlockeduserPage {
    constructor() { }
    ngOnInit() {
    }
};
BlockeduserPage.ctorParameters = () => [];
BlockeduserPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-blockeduser',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./blockeduser.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/blockeduser/blockeduser.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./blockeduser.page.scss */ "./src/app/pages/blockeduser/blockeduser.page.scss")).default]
    })
], BlockeduserPage);



/***/ })

}]);
//# sourceMappingURL=pages-blockeduser-blockeduser-module-es2015.js.map