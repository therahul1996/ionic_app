import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changegender',
  templateUrl: './changegender.page.html',
  styleUrls: ['./changegender.page.scss'],
})
export class ChangegenderPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
