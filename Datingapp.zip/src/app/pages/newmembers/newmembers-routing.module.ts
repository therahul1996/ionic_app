import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { NewmembersPage } from './newmembers.page';

const routes: Routes = [
  {
    path: '',
    component: NewmembersPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NewmembersPageRoutingModule {}
