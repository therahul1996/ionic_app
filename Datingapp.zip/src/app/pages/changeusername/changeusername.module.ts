import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChangeusernamePageRoutingModule } from './changeusername-routing.module';

import { ChangeusernamePage } from './changeusername.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChangeusernamePageRoutingModule
  ],
  declarations: [ChangeusernamePage]
})
export class ChangeusernamePageModule {}
