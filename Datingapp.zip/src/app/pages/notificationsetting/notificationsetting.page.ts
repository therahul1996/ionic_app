import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notificationsetting',
  templateUrl: './notificationsetting.page.html',
  styleUrls: ['./notificationsetting.page.scss'],
})
export class NotificationsettingPage implements OnInit {
disableButton = false;
  constructor() { }

  ngOnInit() {
  }
  truthClick() {
    console.log(this.disableButton);
    if(this.disableButton == true){
      this.disableButton = false;
      
    }
    else{
      this.disableButton = true;
    }
  }

}
