import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NewmembersPageRoutingModule } from './newmembers-routing.module';

import { NewmembersPage } from './newmembers.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NewmembersPageRoutingModule
  ],
  declarations: [NewmembersPage]
})
export class NewmembersPageModule {}
