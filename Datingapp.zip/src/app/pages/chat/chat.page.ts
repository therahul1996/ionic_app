import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, IonContent }  from '@ionic/angular';

@Component({
	selector: 'app-chat',
	templateUrl: './chat.page.html',
	styleUrls: ['./chat.page.scss'],
})
export class ChatPage implements OnInit {
 @ViewChild(IonContent) content: IonContent;
	messages=[
	{
		user:'Srijaul',
		createdAt:1554090956000,
		msg:'Hey buddy whatsup?'
	},
	{
		user:'Oishi',
		createdAt:1554090956000,
		msg:'I am doing fine you?'
	},
	{
		user:'Srijaul',
		createdAt:1554090956000,
		msg:'Same here'
	},

	];
	newMsg = '';
	currentUser = 'Srijaul';
	constructor(public navCtrl: NavController) { }

	sendMessage(){
		this.messages.push({
			user:'Srijaul',
			createdAt: new Date().getTime(),
			msg:this.newMsg
		});
		this.newMsg = '';
		setTimeout(() => {
			this.content.scrollToBottom(200);
		});
		

	}
	ngOnInit() {
	}

}
