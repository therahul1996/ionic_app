import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ChangegenderPageRoutingModule } from './changegender-routing.module';

import { ChangegenderPage } from './changegender.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ChangegenderPageRoutingModule
  ],
  declarations: [ChangegenderPage]
})
export class ChangegenderPageModule {}
