(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-passwordreset-passwordreset-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passwordreset/passwordreset.page.html":
    /*!***************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passwordreset/passwordreset.page.html ***!
      \***************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesPasswordresetPasswordresetPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/\" icon=\"chevron-back\" mode=\"md\" color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Forgot your Password</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <div class=\"dfle\">\n    <ion-row class=\"ion-justify-content-center ion-margin-vertical ion-text-center\">\n      <ion-label color=\"light\">Please enter the email adress for your account.</ion-label>\n    </ion-row>\n    <ion-item lines=\"none\" class=\"cst-item\">\n      <ion-input class=\"cust_input\" placeholder=\"Enter Email\"></ion-input>\n    </ion-item>\n    <ion-button color=\"primary\" mode=\"ios\" shape=\"round\" expand=\"block\" fill=\"solid\" class=\"cmn_btn\">Send</ion-button>\n  </div>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/pages/passwordreset/passwordreset-routing.module.ts":
    /*!*********************************************************************!*\
      !*** ./src/app/pages/passwordreset/passwordreset-routing.module.ts ***!
      \*********************************************************************/

    /*! exports provided: PasswordresetPageRoutingModule */

    /***/
    function srcAppPagesPasswordresetPasswordresetRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PasswordresetPageRoutingModule", function () {
        return PasswordresetPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _passwordreset_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./passwordreset.page */
      "./src/app/pages/passwordreset/passwordreset.page.ts");

      var routes = [{
        path: '',
        component: _passwordreset_page__WEBPACK_IMPORTED_MODULE_3__["PasswordresetPage"]
      }];

      var PasswordresetPageRoutingModule = function PasswordresetPageRoutingModule() {
        _classCallCheck(this, PasswordresetPageRoutingModule);
      };

      PasswordresetPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PasswordresetPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/passwordreset/passwordreset.module.ts":
    /*!*************************************************************!*\
      !*** ./src/app/pages/passwordreset/passwordreset.module.ts ***!
      \*************************************************************/

    /*! exports provided: PasswordresetPageModule */

    /***/
    function srcAppPagesPasswordresetPasswordresetModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PasswordresetPageModule", function () {
        return PasswordresetPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _passwordreset_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./passwordreset-routing.module */
      "./src/app/pages/passwordreset/passwordreset-routing.module.ts");
      /* harmony import */


      var _passwordreset_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./passwordreset.page */
      "./src/app/pages/passwordreset/passwordreset.page.ts");

      var PasswordresetPageModule = function PasswordresetPageModule() {
        _classCallCheck(this, PasswordresetPageModule);
      };

      PasswordresetPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _passwordreset_routing_module__WEBPACK_IMPORTED_MODULE_5__["PasswordresetPageRoutingModule"]],
        declarations: [_passwordreset_page__WEBPACK_IMPORTED_MODULE_6__["PasswordresetPage"]]
      })], PasswordresetPageModule);
      /***/
    },

    /***/
    "./src/app/pages/passwordreset/passwordreset.page.scss":
    /*!*************************************************************!*\
      !*** ./src/app/pages/passwordreset/passwordreset.page.scss ***!
      \*************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesPasswordresetPasswordresetPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background: linear-gradient(to bottom, rgb(235 68 90) 0%, rgb(56 128 255)100%);\n}\n\nion-item.cst-item {\n  border-radius: 50px;\n  margin-bottom: 1rem;\n  width: 100%;\n}\n\n.dfle {\n  display: flex;\n  flex-direction: column;\n  height: 70vh;\n  justify-content: center;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcGFzc3dvcmRyZXNldC9wYXNzd29yZHJlc2V0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVJLGdGQUFBO0FBQUo7O0FBR0E7RUFDSSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsV0FBQTtBQUFKOztBQU9BO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0FBTEoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9wYXNzd29yZHJlc2V0L3Bhc3N3b3JkcmVzZXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gICAgLy8gLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCAjMzUzYjQzIDAlLCAjZGVkZGRkIDEwMCUpO1xyXG4gICAgLS1iYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQodG8gYm90dG9tLCByZ2IoMjM1IDY4IDkwKSAwJSwgcmdiKDU2IDEyOCAyNTUpMTAwJSk7XHJcbn1cclxuXHJcbmlvbi1pdGVtLmNzdC1pdGVtIHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxcmVtO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcblxyXG4gICAgaW9uLWlucHV0IHtcclxuICAgICAgICAvLyAtLXBhZGRpbmctdG9wOiAwO1xyXG4gICAgfVxyXG59XHJcblxyXG4uZGZsZSB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIGhlaWdodDogNzB2aDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/pages/passwordreset/passwordreset.page.ts":
    /*!***********************************************************!*\
      !*** ./src/app/pages/passwordreset/passwordreset.page.ts ***!
      \***********************************************************/

    /*! exports provided: PasswordresetPage */

    /***/
    function srcAppPagesPasswordresetPasswordresetPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PasswordresetPage", function () {
        return PasswordresetPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var PasswordresetPage = /*#__PURE__*/function () {
        function PasswordresetPage() {
          _classCallCheck(this, PasswordresetPage);
        }

        _createClass(PasswordresetPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return PasswordresetPage;
      }();

      PasswordresetPage.ctorParameters = function () {
        return [];
      };

      PasswordresetPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-passwordreset',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./passwordreset.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passwordreset/passwordreset.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./passwordreset.page.scss */
        "./src/app/pages/passwordreset/passwordreset.page.scss"))["default"]]
      })], PasswordresetPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-passwordreset-passwordreset-module-es5.js.map