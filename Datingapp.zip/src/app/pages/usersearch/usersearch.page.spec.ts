import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { UsersearchPage } from './usersearch.page';

describe('UsersearchPage', () => {
  let component: UsersearchPage;
  let fixture: ComponentFixture<UsersearchPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UsersearchPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(UsersearchPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
