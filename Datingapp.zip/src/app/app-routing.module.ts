import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then(m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'login',
    loadChildren: () => import('./pages/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'signup',
    loadChildren: () => import('./pages/signup/signup.module').then( m => m.SignupPageModule)
  },
  {
    path: 'passwordreset',
    loadChildren: () => import('./pages/passwordreset/passwordreset.module').then( m => m.PasswordresetPageModule)
  },
  {
    path: 'discover',
    loadChildren: () => import('./pages/discover/discover.module').then( m => m.DiscoverPageModule)
  },
  {
    path: 'userdetails',
    loadChildren: () => import('./pages/userdetails/userdetails.module').then( m => m.UserdetailsPageModule)
  },
  {
    path: 'profile',
    loadChildren: () => import('./pages/profile/profile.module').then( m => m.ProfilePageModule)
  },
  {
    path: 'viewprofile',
    loadChildren: () => import('./pages/viewprofile/viewprofile.module').then( m => m.ViewprofilePageModule)
  },
  {
    path: 'editprofile',
    loadChildren: () => import('./pages/editprofile/editprofile.module').then( m => m.EditprofilePageModule)
  },
  {
    path: 'verification',
    loadChildren: () => import('./pages/verification/verification.module').then( m => m.VerificationPageModule)
  },
  {
    path: 'changeusername',
    loadChildren: () => import('./pages/changeusername/changeusername.module').then( m => m.ChangeusernamePageModule)
  },
  {
    path: 'changegender',
    loadChildren: () => import('./pages/changegender/changegender.module').then( m => m.ChangegenderPageModule)
  },
  {
    path: 'contactus',
    loadChildren: () => import('./pages/contactus/contactus.module').then( m => m.ContactusPageModule)
  },
  {
    path: 'aboutus',
    loadChildren: () => import('./pages/aboutus/aboutus.module').then( m => m.AboutusPageModule)
  },
  {
    path: 'usersearch',
    loadChildren: () => import('./pages/usersearch/usersearch.module').then( m => m.UsersearchPageModule)
  },
  {
    path: 'blockeduser',
    loadChildren: () => import('./pages/blockeduser/blockeduser.module').then( m => m.BlockeduserPageModule)
  },
  {
    path: 'notificationsetting',
    loadChildren: () => import('./pages/notificationsetting/notificationsetting.module').then( m => m.NotificationsettingPageModule)
  },
  {
    path: 'hiddenuser',
    loadChildren: () => import('./pages/hiddenuser/hiddenuser.module').then( m => m.HiddenuserPageModule)
  },
  {
    path: 'chat',
    loadChildren: () => import('./pages/chat/chat.module').then( m => m.ChatPageModule)
  },
  {
    path: 'messages',
    loadChildren: () => import('./pages/messages/messages.module').then( m => m.MessagesPageModule)
  },
  {
    path: 'search',
    loadChildren: () => import('./pages/search/search.module').then( m => m.SearchPageModule)
  },
  {
    path: 'newmembers',
    loadChildren: () => import('./pages/newmembers/newmembers.module').then( m => m.NewmembersPageModule)
  },
  {
    path: 'favourites',
    loadChildren: () => import('./pages/favourites/favourites.module').then( m => m.FavouritesPageModule)
  },
  {
    path: 'filtermodal',
    loadChildren: () => import('./pages/filtermodal/filtermodal.module').then( m => m.FiltermodalPageModule)
  },
  {
    path: 'verify',
    loadChildren: () => import('./pages/verify/verify.module').then( m => m.VerifyPageModule)
  },
  {
    path: 'gallery',
    loadChildren: () => import('./pages/gallery/gallery.module').then( m => m.GalleryPageModule)
  },
  {
    path: 'viewimage',
    loadChildren: () => import('./pages/viewimage/viewimage.module').then( m => m.ViewimagePageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
