import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { NewmembersPage } from './newmembers.page';

describe('NewmembersPage', () => {
  let component: NewmembersPage;
  let fixture: ComponentFixture<NewmembersPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewmembersPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(NewmembersPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
