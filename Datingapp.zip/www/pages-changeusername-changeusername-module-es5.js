(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-changeusername-changeusername-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/changeusername/changeusername.page.html":
    /*!*****************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/changeusername/changeusername.page.html ***!
      \*****************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPagesChangeusernameChangeusernamePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button text=\"\" icon=\"chevron-back\" defaultHref=\"/profile\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Change Username</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <p>Your Username</p>\n  <p>Srijaul Gazi</p>\n\n  <p class=\"p_user\">Your New Username</p>\n  <ion-input class=\"username\"></ion-input>\n\n</ion-content>\n<ion-footer class=\"ion-no-border ion-padding\">\n  <p class=\"ion-text-center\">You can only change your Username once. Please note that all Username changes are revised\n    by an adminstrator before\n    being approved.</p>\n  <ion-button fill=\"solid\" shape=\"round\" expand=\"block\">Change Username </ion-button>\n</ion-footer>";
      /***/
    },

    /***/
    "./src/app/pages/changeusername/changeusername-routing.module.ts":
    /*!***********************************************************************!*\
      !*** ./src/app/pages/changeusername/changeusername-routing.module.ts ***!
      \***********************************************************************/

    /*! exports provided: ChangeusernamePageRoutingModule */

    /***/
    function srcAppPagesChangeusernameChangeusernameRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangeusernamePageRoutingModule", function () {
        return ChangeusernamePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _changeusername_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./changeusername.page */
      "./src/app/pages/changeusername/changeusername.page.ts");

      var routes = [{
        path: '',
        component: _changeusername_page__WEBPACK_IMPORTED_MODULE_3__["ChangeusernamePage"]
      }];

      var ChangeusernamePageRoutingModule = function ChangeusernamePageRoutingModule() {
        _classCallCheck(this, ChangeusernamePageRoutingModule);
      };

      ChangeusernamePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ChangeusernamePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/pages/changeusername/changeusername.module.ts":
    /*!***************************************************************!*\
      !*** ./src/app/pages/changeusername/changeusername.module.ts ***!
      \***************************************************************/

    /*! exports provided: ChangeusernamePageModule */

    /***/
    function srcAppPagesChangeusernameChangeusernameModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangeusernamePageModule", function () {
        return ChangeusernamePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _changeusername_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./changeusername-routing.module */
      "./src/app/pages/changeusername/changeusername-routing.module.ts");
      /* harmony import */


      var _changeusername_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./changeusername.page */
      "./src/app/pages/changeusername/changeusername.page.ts");

      var ChangeusernamePageModule = function ChangeusernamePageModule() {
        _classCallCheck(this, ChangeusernamePageModule);
      };

      ChangeusernamePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _changeusername_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangeusernamePageRoutingModule"]],
        declarations: [_changeusername_page__WEBPACK_IMPORTED_MODULE_6__["ChangeusernamePage"]]
      })], ChangeusernamePageModule);
      /***/
    },

    /***/
    "./src/app/pages/changeusername/changeusername.page.scss":
    /*!***************************************************************!*\
      !*** ./src/app/pages/changeusername/changeusername.page.scss ***!
      \***************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPagesChangeusernameChangeusernamePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  --background: #f4f5f8;\n}\n\nion-footer {\n  background: #f4f5f8;\n}\n\nion-footer p {\n  font-size: 13px;\n}\n\n.p_user {\n  margin-bottom: 10px;\n}\n\n.username {\n  border: 1px solid #ccc;\n  background: white;\n  border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY2hhbmdldXNlcm5hbWUvY2hhbmdldXNlcm5hbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7QUFDSjs7QUFFQTtFQUNJLG1CQUFBO0FBQ0o7O0FBQ0k7RUFDSSxlQUFBO0FBQ1I7O0FBR0E7RUFDSSxtQkFBQTtBQUFKOztBQUdBO0VBQ0ksc0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FBQUoiLCJmaWxlIjoic3JjL2FwcC9wYWdlcy9jaGFuZ2V1c2VybmFtZS9jaGFuZ2V1c2VybmFtZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNmNGY1Zjg7XHJcbn1cclxuXHJcbmlvbi1mb290ZXIge1xyXG4gICAgYmFja2dyb3VuZDogI2Y0ZjVmODtcclxuXHJcbiAgICBwIHtcclxuICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wX3VzZXIge1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLnVzZXJuYW1lIHtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICBiYWNrZ3JvdW5kOiB3aGl0ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/pages/changeusername/changeusername.page.ts":
    /*!*************************************************************!*\
      !*** ./src/app/pages/changeusername/changeusername.page.ts ***!
      \*************************************************************/

    /*! exports provided: ChangeusernamePage */

    /***/
    function srcAppPagesChangeusernameChangeusernamePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ChangeusernamePage", function () {
        return ChangeusernamePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var ChangeusernamePage = /*#__PURE__*/function () {
        function ChangeusernamePage() {
          _classCallCheck(this, ChangeusernamePage);
        }

        _createClass(ChangeusernamePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ChangeusernamePage;
      }();

      ChangeusernamePage.ctorParameters = function () {
        return [];
      };

      ChangeusernamePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-changeusername',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./changeusername.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/changeusername/changeusername.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./changeusername.page.scss */
        "./src/app/pages/changeusername/changeusername.page.scss"))["default"]]
      })], ChangeusernamePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-changeusername-changeusername-module-es5.js.map