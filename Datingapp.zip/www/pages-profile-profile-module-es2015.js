(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-profile-profile-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header class=\"ion-no-border\">\n  <ion-toolbar color=\"danger\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/discover\" icon=\"chevron-back\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>My profile</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div class=\"cover_img\">\n    <img src=\"../../../assets/img/girl1.jpg\" alt=\"\">\n    <ion-icon name=\"camera-outline\"></ion-icon>\n  </div>\n  <div class=\"profile_img\">\n    <img src=\"../../../assets/img/girl5.jpg\" alt=\"\">\n    <ion-icon name=\"camera-outline\"></ion-icon>\n  </div>\n  <ion-row class=\"ion-padding\">\n    <ion-col class=\"ion-align-self-center\">\n      <ion-label>Profile is visible?</ion-label>\n    </ion-col>\n    <ion-col>\n      <ion-segment (ionChange)=\"segmentChanged($event)\" mode=\"ios\" value=\"yes\">\n        <ion-segment-button value=\"yes\">\n          <ion-label>Yes</ion-label>\n        </ion-segment-button>\n        <ion-segment-button value=\"no\">\n          <ion-label>No</ion-label>\n        </ion-segment-button>\n      </ion-segment>\n    </ion-col>\n  </ion-row>\n  <ion-list>\n    <ion-item routerLink=\"/viewprofile\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"send-sharp\"></ion-icon>\n      <ion-label>View Profile</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/editprofile\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"pencil-sharp\"></ion-icon>\n      <ion-label>Edit Profile</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/verification\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"shield-checkmark-sharp\"></ion-icon>\n      <ion-label>Verification</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/changegender\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"body-sharp\"></ion-icon>\n      <ion-label>Change Gender</ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-icon Slot=\"start\" name=\"calendar-sharp\"></ion-icon>\n      <ion-label>Change Your Birthday</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/changeusername\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"person-sharp\"></ion-icon>\n      <ion-label>Change Username</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/notificationsetting\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"notifications-sharp\">\n      </ion-icon>\n      <ion-label>Notification Settings</ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-icon Slot=\"start\" name=\"share-social-sharp\"></ion-icon>\n      <ion-label>Share with Friends</ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-icon Slot=\"start\" name=\"logo-facebook\"></ion-icon>\n      <ion-label>Invite Facebook Friends</ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-icon Slot=\"start\" name=\"logo-whatsapp\"></ion-icon>\n      <ion-label>Invite WhatsApp Friends</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/contactus\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"mail-unread-sharp\"></ion-icon>\n      <ion-label> Contact Us</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/aboutus\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"information-circle\"></ion-icon>\n      <ion-label> About Us</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/usersearch\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"search-sharp\"></ion-icon>\n      <ion-label> Username Search</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/blockeduser\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"alert-circle\">\n      </ion-icon>\n      <ion-label> Who am I Blocking</ion-label>\n    </ion-item>\n    <ion-item routerLink=\"/hiddenuser\" routerDirection=\"root\" detail>\n      <ion-icon Slot=\"start\" name=\"eye-outline\"></ion-icon>\n      <ion-label> Hidden Members</ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-icon Slot=\"start\" name=\"log-out-outline\"></ion-icon>\n      <ion-label> Sign Out </ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-icon Slot=\"start\" name=\"warning\"></ion-icon>\n      <ion-label> Deactivate Profile</ion-label>\n    </ion-item>\n    <ion-item>\n      <ion-icon Slot=\"start\" name=\"close-circle\"></ion-icon>\n      <ion-label> Delete Profile</ion-label>\n    </ion-item>\n  </ion-list>\n</ion-content>");

/***/ }),

/***/ "./src/app/pages/profile/profile-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/pages/profile/profile-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: ProfilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function() { return ProfilePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./profile.page */ "./src/app/pages/profile/profile.page.ts");




const routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
    }
];
let ProfilePageRoutingModule = class ProfilePageRoutingModule {
};
ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ProfilePageRoutingModule);



/***/ }),

/***/ "./src/app/pages/profile/profile.module.ts":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.module.ts ***!
  \*************************************************/
/*! exports provided: ProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function() { return ProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./profile-routing.module */ "./src/app/pages/profile/profile-routing.module.ts");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile.page */ "./src/app/pages/profile/profile.page.ts");







let ProfilePageModule = class ProfilePageModule {
};
ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"]
        ],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
    })
], ProfilePageModule);



/***/ }),

/***/ "./src/app/pages/profile/profile.page.scss":
/*!*************************************************!*\
  !*** ./src/app/pages/profile/profile.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  --background: #f4f5f8;\n}\n\n.cover_img {\n  height: 190px;\n  width: 100%;\n  position: relative;\n}\n\n.cover_img img {\n  height: 100%;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\n.cover_img ion-icon {\n  font-size: 1.4rem;\n  background: #ccc;\n  padding: 8px;\n  border-radius: 50%;\n  position: absolute;\n  right: 20px;\n  bottom: 15px;\n  border: 1px solid #ccc;\n}\n\n.profile_img {\n  height: 150px;\n  width: 150px;\n  margin: 0 auto;\n  margin-top: -75px;\n  position: relative;\n}\n\n.profile_img img {\n  height: 100%;\n  width: 100%;\n  border: 5px solid #ffffff;\n  border-radius: 50%;\n}\n\n.profile_img ion-icon {\n  font-size: 1.4rem;\n  background: #ccc;\n  padding: 8px;\n  border-radius: 50%;\n  position: absolute;\n  right: 0;\n  bottom: 15px;\n  border: 1px solid #ccc;\n}\n\nion-list {\n  padding: 0;\n  background: transparent;\n}\n\nion-list ion-item {\n  --background: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHFCQUFBO0FBQ0o7O0FBRUE7RUFDSSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0FBQ0o7O0FBQ0k7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUFDUjs7QUFFSTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUFBUjs7QUFJQTtFQUNJLGFBQUE7RUFDQSxZQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFESjs7QUFHSTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxrQkFBQTtBQURSOztBQUlJO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtBQUZSOztBQU1BO0VBQ0ksVUFBQTtFQUNBLHVCQUFBO0FBSEo7O0FBS0k7RUFDSSx5QkFBQTtBQUhSIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1jb250ZW50IHtcclxuICAgIC0tYmFja2dyb3VuZDogI2Y0ZjVmODtcclxufVxyXG5cclxuLmNvdmVyX2ltZyB7XHJcbiAgICBoZWlnaHQ6IDE5MHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICAgaW1nIHtcclxuICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICB9XHJcblxyXG4gICAgaW9uLWljb24ge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMS40cmVtO1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNjY2M7XHJcbiAgICAgICAgcGFkZGluZzogOHB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgcmlnaHQ6IDIwcHg7XHJcbiAgICAgICAgYm90dG9tOiAxNXB4O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5wcm9maWxlX2ltZyB7XHJcbiAgICBoZWlnaHQ6IDE1MHB4O1xyXG4gICAgd2lkdGg6IDE1MHB4O1xyXG4gICAgbWFyZ2luOiAwIGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOiAtNzVweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgICBpbWcge1xyXG4gICAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBib3JkZXI6IDVweCBzb2xpZCAjZmZmZmZmO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIH1cclxuXHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxLjRyZW07XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2NjYztcclxuICAgICAgICBwYWRkaW5nOiA4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICByaWdodDogMDtcclxuICAgICAgICBib3R0b206IDE1cHg7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICAgIH1cclxufVxyXG5cclxuaW9uLWxpc3Qge1xyXG4gICAgcGFkZGluZzogMDtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cclxuICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgfVxyXG59Il19 */");

/***/ }),

/***/ "./src/app/pages/profile/profile.page.ts":
/*!***********************************************!*\
  !*** ./src/app/pages/profile/profile.page.ts ***!
  \***********************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let ProfilePage = class ProfilePage {
    constructor() { }
    ngOnInit() {
    }
};
ProfilePage.ctorParameters = () => [];
ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-profile',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./profile.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/pages/profile/profile.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./profile.page.scss */ "./src/app/pages/profile/profile.page.scss")).default]
    })
], ProfilePage);



/***/ })

}]);
//# sourceMappingURL=pages-profile-profile-module-es2015.js.map