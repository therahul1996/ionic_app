import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { ChangegenderPage } from './changegender.page';

describe('ChangegenderPage', () => {
  let component: ChangegenderPage;
  let fixture: ComponentFixture<ChangegenderPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChangegenderPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(ChangegenderPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
