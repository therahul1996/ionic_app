import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-changeusername',
  templateUrl: './changeusername.page.html',
  styleUrls: ['./changeusername.page.scss'],
})
export class ChangeusernamePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
